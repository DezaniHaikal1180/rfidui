-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2021 at 05:43 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rfidui`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_daftarrfid`
--

CREATE TABLE `tb_daftarrfid` (
  `id` int(100) NOT NULL,
  `rfid` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `telepon` varchar(100) NOT NULL,
  `saldo` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_daftarrfid`
--

INSERT INTO `tb_daftarrfid` (`id`, `rfid`, `nama`, `alamat`, `telepon`, `saldo`) VALUES
(1, 'ASDF123', 'admin', 'indonesia', '1234', 6000),
(2, 'ASDF124', 'Dezan', 'Bogor', '12352637', 23000);

-- --------------------------------------------------------

--
-- Table structure for table `tb_monitoring`
--

CREATE TABLE `tb_monitoring` (
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `rfid` varchar(100) NOT NULL,
  `tol` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_monitoring`
--

INSERT INTO `tb_monitoring` (`tanggal`, `rfid`, `tol`) VALUES
('2021-12-08 04:24:28', 'ASDF123', 'bocimi'),
('2021-12-08 04:15:58', 'ASDF124', 'bocimi');

-- --------------------------------------------------------

--
-- Table structure for table `tb_simpan`
--

CREATE TABLE `tb_simpan` (
  `no` int(100) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `rfid` varchar(100) NOT NULL,
  `saldo_awal` int(255) NOT NULL,
  `bayar` int(255) NOT NULL,
  `saldo_akhir` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_simpan`
--

INSERT INTO `tb_simpan` (`no`, `tanggal`, `rfid`, `saldo_awal`, `bayar`, `saldo_akhir`) VALUES
(73, '2021-12-07 04:58:24', 'ASDF123', 100000, 1000, 99000),
(74, '2021-12-07 04:59:51', 'ASDF124', 99000, 2000, 97000),
(75, '2021-12-07 05:40:09', 'ASDF123', 99000, 1000, 98000),
(76, '2021-12-06 18:03:36', 'ASDF123', 98000, 9000, 89000),
(77, '2021-12-06 18:04:23', 'ASDF123', 89000, 9000, 80000),
(78, '2021-12-06 18:04:58', 'ASDF123', 80000, 9000, 71000),
(79, '2021-12-06 18:07:02', 'ASDF123', 71000, 9000, 62000),
(80, '2021-12-06 18:07:17', 'ASDF123', 62000, 9000, 53000),
(81, '2021-12-06 18:08:09', 'ASDF123', 53000, 9000, 44000),
(82, '2021-12-06 18:08:46', 'ASDF124', 44000, 9000, 35000),
(83, '2021-12-06 18:17:58', 'ASDF124', 44000, 1000, 43000),
(84, '2021-12-06 18:19:27', 'ASDF123', 44000, 1000, 43000),
(85, '2021-12-06 18:20:20', 'ASDF123', 43000, 1000, 42000),
(86, '2021-12-06 18:21:25', 'ASDF123', 42000, 2000, 40000),
(87, '2021-12-06 18:22:42', 'ASDF123', 40000, 1000, 39000),
(88, '2021-12-07 18:56:14', '2AA5B715', 39000, 1000, 38000),
(89, '2021-12-07 18:56:33', 'ASDF123', 39000, 1000, 38000),
(90, '2021-12-07 18:57:04', 'ASDF124', 38000, 1000, 37000),
(91, '2021-12-07 18:57:40', 'ASDF123', 38000, 1000, 37000),
(92, '2021-12-07 19:26:09', '', 37000, 0, 37000),
(93, '2021-12-07 19:26:42', '', 37000, 0, 37000),
(94, '2021-12-07 19:27:13', '', 37000, 0, 37000),
(95, '2021-12-07 19:27:33', '', 37000, 0, 37000),
(96, '2021-12-07 19:27:49', '', 37000, 0, 37000),
(97, '2021-12-07 19:29:26', '', 37000, 0, 37000),
(98, '2021-12-07 19:30:18', '', 37000, 0, 37000),
(99, '2021-12-07 19:32:57', '', 37000, 0, 37000),
(100, '2021-12-07 19:34:30', '', 37000, 0, 37000),
(101, '2021-12-07 19:34:47', '', 37000, 0, 37000),
(102, '2021-12-07 19:35:00', '', 37000, 0, 37000),
(103, '2021-12-07 19:35:59', '', 37000, 0, 37000),
(104, '2021-12-07 20:04:40', 'ASDF123', 37000, 2000, 35000),
(105, '2021-12-07 20:07:38', 'ASDF123', 35000, 2000, 33000),
(106, '2021-12-07 20:09:57', 'ASDF123', 33000, 2000, 31000),
(107, '2021-12-07 20:10:34', 'ASDF123', 31000, 2000, 29000),
(108, '2021-12-07 20:12:53', 'ASDF123', 29000, 0, 29000),
(109, '2021-12-07 20:13:02', '', 29000, 0, 29000),
(110, '2021-12-07 20:14:01', '', 29000, 0, 29000),
(111, '2021-12-07 20:14:37', '', 29000, 0, 29000),
(112, '2021-12-07 20:15:38', '', 29000, 0, 29000),
(113, '2021-12-07 20:15:50', '', 29000, 0, 29000),
(114, '2021-12-07 20:18:13', '', 29000, 0, 29000),
(115, '2021-12-07 20:19:40', '', 29000, 0, 29000),
(116, '2021-12-07 20:24:25', '', 29000, 1000, 28000),
(117, '2021-12-07 20:24:46', '', 29000, 0, 29000),
(118, '2021-12-07 20:25:09', '', 29000, 0, 29000),
(119, '2021-12-07 20:26:09', 'ASDF123', 29000, 1000, 28000),
(120, '2021-12-07 20:28:16', 'ASDF123', 28000, 1000, 27000),
(121, '2021-12-07 20:30:47', 'ASDF123', 27000, 2000, 25000),
(122, '2021-12-07 20:30:53', '', 25000, 2000, 23000),
(123, '2021-12-07 20:31:21', 'ASDF124', 25000, 2000, 23000),
(124, '2021-12-07 20:31:43', '', 25000, 2000, 23000),
(125, '2021-12-07 20:32:17', '', 25000, 0, 25000),
(126, '2021-12-07 20:33:06', '', 25000, 2000, 23000),
(127, '2021-12-07 20:33:20', '', 25000, 0, 25000),
(128, '2021-12-07 20:33:39', '', 25000, 0, 25000),
(129, '2021-12-07 20:34:53', '', 25000, 2000, 23000),
(130, '2021-12-07 20:35:04', '', 25000, 1000, 24000),
(131, '2021-12-07 20:35:21', '', 25000, 0, 25000),
(132, '2021-12-07 20:35:36', '', 25000, 0, 25000),
(133, '2021-12-07 20:35:40', '', 25000, 2000, 23000),
(134, '2021-12-07 20:38:48', 'ASDF124', 25000, 2000, 23000),
(135, '2021-12-07 20:38:54', 'ASDF123', 25000, 2000, 23000),
(136, '2021-12-07 20:39:18', 'ASDF123', 23000, 2000, 21000),
(137, '2021-12-07 20:51:53', '', 21000, 0, 21000),
(138, '2021-12-07 20:52:13', '', 21000, 0, 21000),
(139, '2021-12-07 20:56:17', 'ASDF123', 21000, 0, 21000),
(140, '2021-12-07 20:57:07', 'ASDF123', 21000, 0, 21000),
(141, '2021-12-07 20:57:22', 'ASDF123', 21000, 0, 21000),
(142, '2021-12-08 02:59:38', 'ASDF123', 21000, 0, 21000),
(143, '2021-12-08 03:00:20', 'ASDF123', 21000, 0, 21000),
(144, '2021-12-08 03:03:29', '', 21000, 0, 21000),
(145, '2021-12-08 03:05:51', 'ASDF123', 21000, 0, 21000),
(146, '2021-12-08 03:06:32', '', 21000, 0, 21000),
(147, '2021-12-08 03:06:38', 'ASDF123', 21000, 0, 21000),
(148, '2021-12-07 21:07:24', '', 21000, 0, 21000),
(149, '2021-12-07 21:07:31', 'ASDF123', 21000, 0, 20000),
(150, '2021-12-07 21:09:16', 'ASDF123', 20000, 2000, 19000),
(151, '2021-12-07 21:09:55', '', 19000, 2000, 17000),
(152, '2021-12-07 21:11:27', '', 19000, 2000, 17000),
(153, '2021-12-07 21:12:05', '', 19000, 2000, 17000),
(154, '2021-12-07 21:12:12', '', 19000, 2000, 17000),
(155, '2021-12-07 21:42:27', 'ASDF124', 0, 0, 0),
(156, '2021-12-07 21:46:19', 'ASDF124', 0, 0, 0),
(157, '2021-12-07 21:48:25', 'ASDF123', 19000, 1000, 18000),
(158, '2021-12-07 22:13:33', 'ASDF123', 18000, 2000, 16000),
(159, '2021-12-07 22:13:40', 'ASDF123', 18000, 1000, 17000),
(160, '2021-12-07 22:14:09', 'ASDF123', 18000, 1000, 17000),
(161, '2021-12-07 22:16:05', 'ASDF123', 18000, 1000, 17000),
(162, '2021-12-07 22:16:48', 'ASDF123', 18000, 2000, 16000),
(163, '2021-12-07 22:16:57', 'ASDF123', 16000, 1000, 15000),
(164, '2021-12-07 22:20:01', 'ASDF123', 15000, 2000, 13000),
(165, '2021-12-08 04:20:23', 'ASDF123', 13000, 2000, 11000),
(166, '2021-12-08 04:23:18', 'ASDF123', 11000, 2000, 9000),
(167, '2021-12-08 04:23:58', 'ASDF123', 9000, 2000, 7000),
(168, '2021-12-08 04:24:28', 'ASDF123', 7000, 1000, 6000);

-- --------------------------------------------------------

--
-- Table structure for table `tb_tol`
--

CREATE TABLE `tb_tol` (
  `id` int(11) NOT NULL,
  `tol` varchar(100) NOT NULL,
  `harga` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_tol`
--

INSERT INTO `tb_tol` (`id`, `tol`, `harga`) VALUES
(1, 'jagorawi', '2000'),
(2, 'bocimi', '1000');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id` int(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin'),
(2, 'user1', 'user1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_daftarrfid`
--
ALTER TABLE `tb_daftarrfid`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_simpan`
--
ALTER TABLE `tb_simpan`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `tb_tol`
--
ALTER TABLE `tb_tol`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_daftarrfid`
--
ALTER TABLE `tb_daftarrfid`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_simpan`
--
ALTER TABLE `tb_simpan`
  MODIFY `no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=169;

--
-- AUTO_INCREMENT for table `tb_tol`
--
ALTER TABLE `tb_tol`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
