-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 09, 2021 at 05:56 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rfidui`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_daftarrfid`
--

CREATE TABLE `tb_daftarrfid` (
  `id` int(100) NOT NULL,
  `rfid` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `telepon` varchar(100) NOT NULL,
  `saldo` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_daftarrfid`
--

INSERT INTO `tb_daftarrfid` (`id`, `rfid`, `nama`, `alamat`, `telepon`, `saldo`) VALUES
(1, '1ACE980', 'admin', 'indonesia', '1234', 44000),
(2, '4A516EAE', 'Dezan', 'Bogor', '12352637', 13000);

-- --------------------------------------------------------

--
-- Table structure for table `tb_monitoring`
--

CREATE TABLE `tb_monitoring` (
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `rfid` varchar(100) NOT NULL,
  `tol` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_monitoring`
--

INSERT INTO `tb_monitoring` (`tanggal`, `rfid`, `tol`) VALUES
('2021-12-09 04:47:58', '1ACE980', 'jagorawi');

-- --------------------------------------------------------

--
-- Table structure for table `tb_simpan`
--

CREATE TABLE `tb_simpan` (
  `no` int(100) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `rfid` varchar(100) NOT NULL,
  `saldo_awal` int(255) NOT NULL,
  `bayar` int(255) NOT NULL,
  `saldo_akhir` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_simpan`
--

INSERT INTO `tb_simpan` (`no`, `tanggal`, `rfid`, `saldo_awal`, `bayar`, `saldo_akhir`) VALUES
(174, '2021-12-09 01:07:34', 'ASDF123', 100000, 2000, 98000),
(175, '2021-12-09 01:12:08', 'ASDF123', 98000, 1000, 97000),
(176, '2021-12-09 01:12:43', 'ASDF123', 97000, 1000, 96000),
(177, '2021-12-09 01:27:00', '4A516EAE?tol=4A516EAE', 0, 0, 0),
(178, '2021-12-09 01:28:18', '4A516EAE?tol=4A516EAE', 0, 0, 0),
(179, '2021-12-09 01:29:38', '4A516EAE?tol=4A516EAE', 0, 0, 0),
(180, '2021-12-09 01:30:05', '4A516EAE?tol=4A516EAE', 0, 0, 0),
(181, '2021-12-09 01:31:11', '4A516EAE', 23000, 0, 23000),
(182, '2021-12-09 01:36:19', '4A516EAE', 23000, 2000, 21000),
(183, '2021-12-09 01:42:27', '4A516EAE', 21000, 0, 21000),
(184, '2021-12-09 01:46:13', '4A516EAE', 21000, 2000, 19000),
(185, '2021-12-09 02:21:31', '4A516EAE', 19000, 2000, 17000),
(186, '2021-12-09 02:25:16', '4A516EAE', 17000, 2000, 15000),
(187, '2021-12-09 02:26:08', '4A516EAE', 15000, 0, 15000),
(188, '2021-12-09 02:27:04', '4A516EAE', 15000, 2000, 13000),
(189, '2021-12-09 03:35:05', '1ACE980', 96000, 2000, 94000),
(190, '2021-12-09 03:35:31', '1ACE980', 94000, 2000, 92000),
(191, '2021-12-09 03:42:39', '1ACE980', 92000, 2000, 90000),
(192, '2021-12-09 03:42:59', '1ACE980', 90000, 2000, 88000),
(193, '2021-12-09 03:45:02', '1ACE980', 88000, 2000, 86000),
(194, '2021-12-09 03:45:53', '1ACE980', 86000, 2000, 84000),
(195, '2021-12-09 03:47:39', '1ACE980', 84000, 2000, 82000),
(196, '2021-12-09 03:47:41', '1ACE980', 82000, 2000, 80000),
(197, '2021-12-09 03:47:54', '1ACE980', 80000, 2000, 78000),
(198, '2021-12-09 03:48:58', '1ACE980', 78000, 2000, 76000),
(199, '2021-12-09 03:49:27', '1ACE980', 76000, 2000, 74000),
(200, '2021-12-09 04:09:44', '1ACE980', 74000, 2000, 72000),
(201, '2021-12-09 04:09:59', '1ACE980', 72000, 2000, 70000),
(202, '2021-12-09 04:11:16', '1ACE980', 70000, 2000, 68000),
(203, '2021-12-09 04:11:26', '1ACE980', 68000, 2000, 66000),
(204, '2021-12-09 04:19:35', '1ACE980', 66000, 2000, 64000),
(205, '2021-12-09 04:23:25', '1ACE980', 64000, 2000, 62000),
(206, '2021-12-09 04:24:18', '1ACE980', 62000, 2000, 60000),
(207, '2021-12-09 04:30:40', '1ACE980', 60000, 2000, 58000),
(208, '2021-12-09 04:34:58', '1ACE980', 58000, 2000, 56000),
(209, '2021-12-09 04:36:43', '1ACE980', 56000, 2000, 54000),
(210, '2021-12-09 04:41:16', '1ACE980', 54000, 2000, 52000),
(211, '2021-12-09 04:42:25', '1ACE980', 52000, 2000, 50000),
(212, '2021-12-09 04:44:55', '1ACE980', 50000, 2000, 48000),
(213, '2021-12-09 04:47:47', '1ACE980', 48000, 2000, 46000),
(214, '2021-12-09 04:47:58', '1ACE980', 46000, 2000, 44000);

-- --------------------------------------------------------

--
-- Table structure for table `tb_tol`
--

CREATE TABLE `tb_tol` (
  `id` int(11) NOT NULL,
  `tol` varchar(100) NOT NULL,
  `harga` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_tol`
--

INSERT INTO `tb_tol` (`id`, `tol`, `harga`) VALUES
(1, 'jagorawi', '2000'),
(2, 'bocimi', '1000');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id` int(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin'),
(2, 'user1', 'user1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_daftarrfid`
--
ALTER TABLE `tb_daftarrfid`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_simpan`
--
ALTER TABLE `tb_simpan`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `tb_tol`
--
ALTER TABLE `tb_tol`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_daftarrfid`
--
ALTER TABLE `tb_daftarrfid`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_simpan`
--
ALTER TABLE `tb_simpan`
  MODIFY `no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=215;

--
-- AUTO_INCREMENT for table `tb_tol`
--
ALTER TABLE `tb_tol`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
