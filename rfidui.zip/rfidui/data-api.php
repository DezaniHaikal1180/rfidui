<?php 
   
   require "koneksidb.php";
   $data 		= query("SELECT * FROM tb_daftarrfid")[0];
   $ambilrfid	 = $_GET["rfid"];
   date_default_timezone_set('Asia/Jakarta');
   $tgl=date("Y-m-d G:i:s");
   $ambiltol	= $_GET["tol"];
   $saldo		= $data["saldo"];

   	  	// $data = query("SELECT * FROM tabel_monitoring")[0];

   	$harga		= query("SELECT harga FROM tb_tol WHERE tol='$ambiltol'")[0];
   	$bayar      = $harga['harga'];
   	
   	$saldo		= query("SELECT saldo FROM tb_daftarrfid WHERE rfid='$ambilrfid'")[0];
   	$saldo_awal = $saldo['saldo'];

		//UPDATE DATA REALTIME PADA TABEL tb_monitoring
   		if($saldo < $bayar){
   			echo "<script>alert('Maaf Saldo Anda Tidak Mencukupi');history.go(-1);</script>";
   		}else {
		$sql      = "UPDATE tb_monitoring SET tanggal	= '$tgl', tol='$ambiltol'  WHERE rfid	= '$ambilrfid'";
		$koneksi->query($sql);

		$sisa = $saldo_awal - $bayar;
		$koneksi->query($sisa);


		$saldo_akhir = "UPDATE tb_daftarrfid SET saldo = '$sisa' WHERE rfid='$ambilrfid'";
		$koneksi->query($saldo_akhir);


		$sqlsave = "INSERT INTO tb_simpan (tanggal, rfid, saldo_awal, bayar, saldo_akhir ) VALUES (
		'". $tgl . "',
		'". $ambilrfid . "',
		'". $saldo_awal . "',
		'". $bayar . "',
		'". $sisa . "'
		) ";
		$koneksi->query($sqlsave);
		echo "<script>alert('Transaksi Berhasil');history.go(-1);</script>";

		//UPDATE DATA REALTIME PADA TABLE tb_daftarrfid

		// $sisa = $saldo - $bayar;
		// $koneksi->query($sisa);

		// $saldo_akhir	="UPDATE tb_daftarrfid SET saldo = '$sisa' WHERE rfid = '$ambilrfid'";
		// $koneksi->query($saldo_akhir);

		//INSERT DATA REALTIME PADA TABEL tb_save  	
		// $sqlsave = "INSERT INTO tb_simpan (tanggal, rfid, saldo_awal, bayar, saldo_akhir) VALUES ( 
		// '" . $tgl . "', 
		// '" . $ambilrfid . "',
		// '" . $saldo . "',
		// '" . $bayar . "',
		// '" . $sisa . "'
		// )";
		// $koneksi->query($sqlsave);

		//MENJADIKAN JSON DATA
		//$response = query("SELECT * FROM tb_monitoring")[0];
		// $response = query("SELECT * FROM tb_daftarrfid,tb_monitoring WHERE tb_daftarrfid.rfid='$ambilrfid'" )[0];
  //     	$result = json_encode($response);
  //    	echo $result;

     	}


 ?>