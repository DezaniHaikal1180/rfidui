<?php 
   
   require "koneksidb.php";
   $data 		= query("SELECT * FROM tb_daftarrfid")[0];
   $ambilrfid	 = $_GET["rfid"];
   $tgl=date("Y-m-d h:i:s");
   $bayar		= $_GET["bayar"];
   $saldo		= $data["saldo"];

   	  	// $data = query("SELECT * FROM tabel_monitoring")[0];
		//UPDATE DATA REALTIME PADA TABEL tb_monitoring
   		if($saldo < $bayar){
   			echo "<script>alert('Maaf Saldo Anda Tidak Mencukupi');history.go(-1);</script>";
   		}else {
		$sql      = "UPDATE tb_monitoring SET tanggal	= '$tgl' , bayar = '$bayar' WHERE rfid	= '$ambilrfid'";
		$koneksi->query($sql);

		//UPDATE DATA REALTIME PADA TABLE tb_daftarrfid

		$sisa = $saldo - $bayar;
		$koneksi->query($sisa);

		$saldo_akhir	="UPDATE tb_daftarrfid SET saldo = '$sisa' WHERE rfid = '$ambilrfid'";
		$koneksi->query($saldo_akhir);

		//INSERT DATA REALTIME PADA TABEL tb_save  	
		$sqlsave = "INSERT INTO tb_simpan (tanggal, rfid, saldo_awal, bayar, saldo_akhir) VALUES ( 
		'" . $tgl . "', 
		'" . $ambilrfid . "',
		'" . $saldo . "',
		'" . $bayar . "',
		'" . $sisa . "'
		)";
		$koneksi->query($sqlsave);

		//MENJADIKAN JSON DATA
		//$response = query("SELECT * FROM tb_monitoring")[0];
		$response = query("SELECT * FROM tb_daftarrfid,tb_monitoring WHERE tb_daftarrfid.rfid='$ambilrfid'" )[0];
      	$result = json_encode($response);
     	echo $result;

     	}


 ?>